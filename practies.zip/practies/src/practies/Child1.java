package practies;

class Child1 extends Parent {
	public Child1(int x) {
		System.out.println("I am Child");
	}

	public static void main(String[] args) {
		Child1 c = new Child1(10);
	}
}