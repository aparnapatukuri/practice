package practies;

public class ListManager
{
	public void expandList(MyList l)
	{
		 l.size=l.size+10;
		 }
	}//end of ListManager