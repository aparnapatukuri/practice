package practies;

import java.util.Vector;

public class MyList1 {
	static int size;

	public expandList(int newSize)
	{
		ListExpander lexp=new ListExpander();
		Vector expandedList=lexp.expand();
		
		class ListExpander
		{
			public Vector expand()
			{
				Vector v=new Vector(this.size+newSize);
				return v;
		    }
		}
	}
}