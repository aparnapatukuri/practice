package practies;

public class Parent {
	public Parent() {
		System.out.println("I am Parent");
	}
}

