package practies;

public class Test
{
	public void main()
	{
		System.out.println("Hi");
		}
	public static void main (String [] args)
	{
		Test t=new Test();
		t.main();
		}
	}