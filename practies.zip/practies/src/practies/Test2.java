package practies;

public class Test2 {
	String x;
	public void testDemo(int n){
		String y;
		if ( n>0) { 
			y="Hello";
			}
	System.out.println(x+y);
	}
	public static void main(String [] args){
		Test2 test=new Test2();
		test.testDemo(2);}}